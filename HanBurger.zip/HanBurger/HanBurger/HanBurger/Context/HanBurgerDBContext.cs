﻿using HanBurger.Context.EntitiyTypeConfiguration;
using HanBurger.Context.Seed;
using HanBurger.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Context
{
    public partial class HanBurgerDBContext : IdentityDbContext<AppUser>
    {
        public HanBurgerDBContext()
        {
        }

        public HanBurgerDBContext(DbContextOptions<HanBurgerDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Category> Categories { get; set; } = null!;
        public virtual DbSet<Order> Orders { get; set; } = null!;
        public virtual DbSet<OrdersProduct> OrdersProducts { get; set; } = null!;
        public virtual DbSet<Product> Products { get; set; } = null!;
        public virtual DbSet<AppUser> AppUsers { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            CategorySeed categorySeed = new CategorySeed();
            ProductSeed productSeed = new ProductSeed();
            modelBuilder.ApplyConfiguration(new CategoryTypeConfiguration())
                       .ApplyConfiguration(new OrdersProductTypeConfiguration())
                       .ApplyConfiguration(new OrderTypeConfiguration())
                       .ApplyConfiguration(new ProductTypeConfiguration());

            //menuSeed.AddMenuData(modelBuilder);
            categorySeed.AddCategoryData(modelBuilder);
            productSeed.AddProductData(modelBuilder);
            base.OnModelCreating(modelBuilder);
            OnModelCreatingPartial(modelBuilder);
            modelBuilder.Entity<IdentityRole>().HasData(
                                                new IdentityRole { Id = "1", Name = "Admin", NormalizedName = "ADMIN" },
                                                new IdentityRole { Id = "2", Name = "User", NormalizedName = "USER" });
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
