﻿using HanBurger.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HanBurger.Context.EntitiyTypeConfiguration
{
    public class OrdersProductTypeConfiguration : IEntityTypeConfiguration<OrdersProduct>
    {
        public void Configure(EntityTypeBuilder<OrdersProduct> builder)
        {
            builder.HasKey(e => new { e.ProductId, e.OrderId });

            builder.Property(e => e.ProductId).HasColumnName("ProductID");

            builder.Property(e => e.OrderId).HasColumnName("OrderID");

            builder.Property(e => e.SelectedSauces)
                   .HasConversion(
                    v => string.Join(',', v),
                    v => v.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList()
                    )
                   .HasMaxLength(255)
                   .IsUnicode(false);

            builder.HasOne(d => d.Order)
                    .WithMany(p => p.OrdersProducts)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.NoAction)
                    .HasConstraintName("FK_OrdersProducts_Orders");

            builder.HasOne(d => d.Product)
                    .WithMany(p => p.OrdersProducts)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.NoAction)
                    .HasConstraintName("FK_OrdersProducts_Products");
        }
    }
}
