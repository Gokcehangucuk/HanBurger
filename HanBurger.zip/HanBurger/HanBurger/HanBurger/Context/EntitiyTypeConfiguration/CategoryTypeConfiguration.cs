﻿using HanBurger.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HanBurger.Context.EntitiyTypeConfiguration
{
    public class CategoryTypeConfiguration : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.Property(e => e.CategoryId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("CategoryID").UseIdentityColumn(1, 1);

            builder.Property(e => e.Description).HasMaxLength(500);

            builder.Property(e => e.Name).HasMaxLength(30);

            builder.Property(e => e.PhotoPath).HasMaxLength(50);
            builder.Property(e => e.IsActive)
                                            .HasColumnName("IsActive")
                                            .IsRequired()
                                            .HasColumnType("bit")
                                            .HasDefaultValue(true);
        }
    }
}
