﻿using HanBurger.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HanBurger.Context.EntitiyTypeConfiguration
{
	public class OrderTypeConfiguration : IEntityTypeConfiguration<Order>
	{
		public void Configure(EntityTypeBuilder<Order> builder)
		{

			builder.Property(e => e.OrderId)
					.ValueGeneratedOnAdd()
					.HasColumnName("OrderID")
					.UseIdentityColumn(1, 1);

			builder.Property(e => e.OrderDate).HasColumnType("date");

			builder.Property(e => e.Status).HasMaxLength(50);

			builder.Property(e => e.TotalPrice)
					.HasMaxLength(10)
					.IsFixedLength();

			builder.Property(e => e.UserId)
					.HasColumnName("UserID");

			builder.HasOne(d => d.User)
					.WithMany(p => p.Orders)
					.HasForeignKey(d => d.UserId)
					.OnDelete(DeleteBehavior.NoAction)
					.HasConstraintName("FK_Orders_User");

		}
	}
}
