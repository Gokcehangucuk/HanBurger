﻿using HanBurger.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HanBurger.Context.EntitiyTypeConfiguration
{
	public class ProductTypeConfiguration : IEntityTypeConfiguration<Product>
	{
		public void Configure(EntityTypeBuilder<Product> builder)
		{
			builder.Property(e => e.ProductId)
					.ValueGeneratedOnAdd()
					.HasColumnName("ProductID")
					.UseIdentityColumn(1, 1);

			builder.Property(e => e.CategoryId).HasColumnName("CategoryID");

			builder.Property(e => e.Description).HasMaxLength(200);

			builder.Property(e => e.Name).HasMaxLength(50);

			builder.Property(e => e.PhotoPath).HasMaxLength(50);

			builder.Property(e => e.Price).HasColumnType("decimal(18, 0)");

			builder.HasOne(d => d.Category)
					.WithMany(p => p.Products)
					.HasForeignKey(d => d.CategoryId)
					.OnDelete(DeleteBehavior.NoAction)
					.HasConstraintName("FK_Products_Categories");
		}
	}
}
