﻿using HanBurger.Models;
using HanBurger.Models.Enums;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Context.Seed
{
    public class ProductSeed
    {
        public void AddProductData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                //Burgerler
                new Product { ProductId = 1, CategoryId = 1, Name = "Whopper", SalesStatus = SalesStatus.InSale, Description = "Whopper® eti (dana), 5'' ekmek, turşu, ketçap, mayonez, göbek salata, domates, soğan", PhotoPath = "~/img/Burgers/Whopper.webp", Price = 125 },

                new Product { ProductId = 2, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Big King", Description = "Hamburger eti (dana), 3,75'' ekmek, 1 dilim peynir, turşu, Big King sosu, göbek salata, soğan", PhotoPath = "~/img/Burgers/BigKing.webp", Price = 110 },

                new Product { ProductId = 3, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "BK Steakhouse Burger", Description = "Baharatlı Steak Köftesi, 4,5'' ekmek, mayonez, domates, göbek salata, 2 dilim peynir, özel steak sos, çıtır soğan", PhotoPath = "~/img/Burgers/BKSteakhouseBurger.webp", Price = 140 },

                new Product { ProductId = 4, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Texas Smokehouse Burger", Description = "Texas Smokehouse Burger®, Whopper® eti (dana), 4,5” ekmek, 2 dilim cheddar peyniri, füme kaburga et, barbekü sos, çıtır soğan", PhotoPath = "~/img/Burgers/TexasSmokehouseBurger.webp", Price = 147 },

                new Product { ProductId = 5, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Whopper Jr.", Description = "Whopper® eti (dana), 5'' ekmek, turşu, ketçap, mayonez, göbek salata, domates, soğan", PhotoPath = "~/img/Burgers/WhopperJr.webp", Price = 90 },

                new Product { ProductId = 6, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Double Whopper", Description = "Whopper® eti (dana), 5'' ekmek, turşu, ketçap, mayonez, göbek salata, domates, soğan", PhotoPath = "~/img/Burgers/DoubleWhopper.webp", Price = 160 },


                new Product { ProductId = 7, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = " Etli Barbekü Brioche", Description = "4,5 \" brioche ekmek, Whopper eti, 2 dilim peynir, marul, mayonez, barbekü sos, çıtır soğan", PhotoPath = "~/img/Burgers/EtliBarbeküBrioche.webp", Price = 128 },

                new Product { ProductId = 8, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Big King XXL", Description = "Whopper® eti (dana), 5'' ekmek, 4 dilim peynir, turşu, Big King sosu, göbek salata, soğan", PhotoPath = "~/img/Burgers/BigKingXXL.webp", Price = 180 },

                new Product { ProductId = 9, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Double Cheeseburger", Description = "Hamburger eti (dana), 3,75'' ekmek, 2 dilim peynir, turşu, hardal, ketçap", PhotoPath = "~/img/Burgers/DoubleCheeseburger.webp", Price = 110 },

                new Product { ProductId = 10, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Rodeo Whoppe", Description = "Whopper eti, 5\" ekmek, mayonez, göbek salata, 4 adet soğan halkası, 2 dilim domates, barbekü sos, 2 dilim peynir", PhotoPath = "~/img/Burgers/RodeoWhoppe.webp", Price = 140 },

                new Product { ProductId = 11, CategoryId = 1, SalesStatus = SalesStatus.InSale, Name = "Cheeseburger", Description = "Hamburger eti (dana), 3,75'' ekmek, 1 dilim peynir, turşu, hardal, ketçap", PhotoPath = "~/img/Burgers/Cheeseburger.webp", Price = 84 },

                //------------------ Tatlılar -----------------//
                new Product { ProductId = 12, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Böğürtlenli Çikolatalı Pasta", Description = "Eşsiz Lezzet Böğürtlenli Çikolatalı Pasta", PhotoPath = "~/img/Desserts/BöğürtlenliÇikolatalıPasta.webp", Price = 24 },

                new Product { ProductId = 13, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Brownie", Description = "Eşsiz Lezzet Brownie ", PhotoPath = "~/img/Desserts/Brownie.webp", Price = 24 },

                new Product { ProductId = 14, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Çikolatalı Muffin", Description = "Eşsiz Lezzet Çikolatalı Muffin", PhotoPath = "~/img/Desserts/ÇikolatalıMuffin.webp", Price = 21 },

                new Product { ProductId = 15, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Çokoburger", Description = "Eşsiz Lezzet Çokoburger", PhotoPath = "~/img/Desserts/Çokoburger.webp", Price = 18 },

                new Product { ProductId = 16, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Frambuazlı Cheesecake", Description = "Eşsiz Lezzet Frambuazlı Cheesecake", PhotoPath = "~/img/Desserts/FrambuazlıCheesecake.webp", Price = 24 },

                new Product { ProductId = 17, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Ekler", Description = "Eşsiz Lezzet Ekler", PhotoPath = "~/img/Desserts/Ekler.webp", Price = 14 },

                new Product { ProductId = 18, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Mozaik Pasta", Description = "Eşsiz Lezzet Mozaik Pasta", PhotoPath = "~/img/Desserts/MozaikPasta.webp", Price = 24 },

                new Product { ProductId = 19, CategoryId = 2, SalesStatus = SalesStatus.InSale, Name = "Muffin", Description = "Eşsiz Lezzet Muffin", PhotoPath = "~/img/Desserts/Muffin.webp", Price = 17 },

                //-----------------Soslar -------------/
                new Product { ProductId = 20, CategoryId = 3, SalesStatus = SalesStatus.InSale, Name = "Ketçap", Description = "Eşsiz Lezzet Ketçap ", PhotoPath = "~/img/Sauces/Ketçap.webp", Price = 2.5m },

                new Product { ProductId = 21, CategoryId = 3, SalesStatus = SalesStatus.InSale, Name = "Mayonez ", Description = "Eşsiz Lezzet Mayonez  ", PhotoPath = "~/img/Sauces/Mayonez.webp", Price = 2.5m },

                new Product { ProductId = 22, CategoryId = 3, SalesStatus = SalesStatus.InSale, Name = "Acı Sos", Description = "Eşsiz Lezzet Acı Sos ", PhotoPath = "~/img/Sauces/AcıSos.webp", Price = 2.5m },

                new Product { ProductId = 23, CategoryId = 3, SalesStatus = SalesStatus.InSale, Name = "Barbekü Sos", Description = "Eşsiz Lezzet Barbekü Sos ", PhotoPath = "~/img/Sauces/BarbeküSos.webp", Price = 3.5m },

                new Product { ProductId = 24, CategoryId = 3, SalesStatus = SalesStatus.InSale, Name = "Buffalo Sos", Description = "Eşsiz Lezzet Buffalo Sos ", PhotoPath = "~/img/Sauces/BuffaloSos.webp", Price = 3.5m },

                new Product { ProductId = 25, CategoryId = 3, SalesStatus = SalesStatus.InSale, Name = "Ballı Hardal", Description = "Eşsiz Lezzet Ballı Hardal ", PhotoPath = "~/img/Sauces/BallıHardal.webp", Price = 3.5m },


            //------------- İçecekler --------------//
            new Product { ProductId = 26, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Coca-Cola (33 cl.)", Description = "Eşsiz Lezzet Coca-Cola (33 cl.)", PhotoPath = "~/img/Drinks/Coca-Cola(33 cl.).webp", Price = 18 },

            new Product { ProductId = 27, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Fuse Tea Şeftali (33 cl.)", Description = "Eşsiz Lezzet Fuse Tea Şeftali (33 cl.)", PhotoPath = "~/img/Drinks/FuseTeaŞeftali(33 cl.).webp", Price = 18 },

            new Product { ProductId = 28, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Fuse Tea Limon (33 cl.)", Description = "Eşsiz Lezzet Fuse Tea Limon (33 cl.)", PhotoPath = "~/img/Drinks/FuseTeaLimon(33 cl.).webp", Price = 18 },

            new Product { ProductId = 29, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Sprite(33 cl.)", Description = "Eşsiz Lezzet Sprite ", PhotoPath = "~/img/Drinks/Sprite(33 cl.).webp", Price = 18 },

            new Product { ProductId = 30, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Fanta (33 cl.)", Description = "Eşsiz Lezzet Fanta  (33 cl.)", PhotoPath = "~/img/Drinks/Fanta(33 cl.).webp", Price = 18 },

            new Product { ProductId = 31, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Coca-Cola (1 L.)", Description = "Eşsiz Lezzet Coca-Cola (1 L.)", PhotoPath = "~/img/Drinks/Coca-Cola(1 L.).webp", Price = 22 },


            new Product { ProductId = 32, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Fuse Tea Şeftali (1 L.)", Description = "Eşsiz Lezzet Fuse Tea Şeftali (1 L.)", PhotoPath = "~/img/Drinks/FuseTeaŞeftali(1 L.).webp", Price = 22 },

            new Product { ProductId = 33, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Fuse Tea Limon (1 L.)", Description = "Eşsiz Lezzet Fuse Tea Limon (1 L.)", PhotoPath = "~/img/Drinks/FuseTeaLimon(1 L.).webp", Price = 22 },

            new Product { ProductId = 34, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Sprite (1 L.)", Description = "Eşsiz Lezzet Sprite (1 L.)", PhotoPath = "~/img/Drinks/Sprite(1 L.).webp", Price = 22 },

            new Product { ProductId = 35, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Fanta (1 L.)", Description = "Eşsiz Lezzet Fanta  (1 L.)", PhotoPath = "~/img/Drinks/Fanta(1 L.).webp", Price = 22 },

            new Product { ProductId = 36, CategoryId = 4, SalesStatus = SalesStatus.InSale, Name = "Su", Description = "Eşsiz Lezzet Su", PhotoPath = "~/img/Drinks/Su.webp", Price = 8 },

            //----------------------------------Özel Menüler---------------------------------------//

            new Product { ProductId = 37, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel Double Cheeseburger Menü", Description = "Double Cheeseburger + Patates Kızartması (Orta) + BK King Nuggets (4'lü) + Kutu İçecek", PhotoPath = "~/img/Menus/ÖzelDoubleCheeseburgerMenü.webp", Price = 120 },

                new Product { ProductId = 38, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel Double Whooper Jr.® Menü", Description = "Double Whooper Jr.® + Orta Patates + Soğan Halkası (8'li) + Kutu İçecek", PhotoPath = "~/img/Menus/ÖzelDoubleWhooperJr.®Menü.webp", Price = 130 },

                new Product { ProductId = 39, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel BK Steakhouse Burger", Description = "BK Steakhouse Burger® + Patates Kızartması (Orta) + Soğan Halkası (6'lı) + Kutu İçecek", PhotoPath = "~/img/Menus/ÖzelBKSteakhouseBurger.webp", Price = 150 },

                new Product { ProductId = 40, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel Big King® Menü", Description = "Big King® + Patates Kızartması (Orta) + Kutu İçecek", PhotoPath = "~/img/Menus/ÖzelBigKing®Menü.®Menü.webp", Price = 105 },

                new Product { ProductId = 41, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel Burger King® Menü", Description = "2 Adet Chicken Royale + Orta Boy Patates + 4'lü Soğan Halkası + 1 L. İçecek", PhotoPath = "~/img/Menus/ÖzelBurgerKing®Menü.webp", Price = 120 },

                new Product { ProductId = 42, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel Galatasaray Menüsü ", Description = "Etli BBQ Deluxe + Chicken Royale + Patates Kızartması (Orta) + Soğan Halkası (4’lü) + 1 L. İçecek", PhotoPath = "~/img/Menus/Özel-Galatasaray®Menü.webp", Price = 135 },

                new Product { ProductId = 43, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel Double King Chicken® Menü ", Description = "Double King Chicken® + Patates Kızartması (Orta) + Kutu İçecek", PhotoPath = "~/img/Menus/ÖzelDoubleKingChicken®Menü.webp", Price = 90 },

                new Product { ProductId = 44, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel Benim İkilim ", Description = "2 Adet Seçeceğiniz Sandviç + Patates Kızartması (Orta) + 1 L. İçecek", PhotoPath = "~/img/Menus/ÖzelBenimİkilim®Menü.webp", Price = 100 },

                new Product { ProductId = 45, CategoryId = 5, SalesStatus = SalesStatus.InSale, Name = "Özel 3'lü Whopper®  ", Description = "3 Adet Whopper Jr.® + Patates Kızartması (Büyük) + Coca-Cola (1 L.)", PhotoPath = "~/img/Menus/Özel3'lüWhopper®Menü.webp", Price = 180 },

                //----------------------------------Menüler---------------------------------------//
                new Product { ProductId = 46, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "Kral İkili Menü", Description = "Big King® + King Chicken® + Patates Kızartması (Orta) + 1 L İçecek", PhotoPath = "~/img/Menus/KralİkiliMenü.webp", Price = 165 },

                new Product { ProductId = 47, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "Kral Avantaj Menü", Description = "BDouble Whopper Jr.® + King Chicken® + Orta Boy Patates + 4’lü Soğan Halkası + 1L. İçecek", PhotoPath = "~/img/Menus/KralAvantajMenü.webp", Price = 145 },

                new Product { ProductId = 48, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "2'li Big King Menü", Description = "Big King® + Big King® + Patates Kızartması (Orta) +1 L. İçecek", PhotoPath = "~/img/Menus/2'liBigKingMenü.webp", Price = 200 },

                new Product { ProductId = 49, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "Benim Üçlüm Menü", Description = "Big King® + King Chicken® + Patates Kızartması (Orta) + 1 L İçecek", PhotoPath = "~/img/Menus/BenimÜçlümMenü.webp", Price = 140 },

                new Product { ProductId = 50, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "Benim Dörtlüm Menü", Description = "4 Adet Seçeceğiniz Sandviç + Patates Kızartması (Büyük) + 1 L. ", PhotoPath = "~/img/Menus/BenimDörtlümMenü.webp", Price = 140 },

                new Product { ProductId = 51, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "Pro Gamer Big King® Menü", Description = "Big King® + Patates Kızartması (Orta) + Soğan Halkaları (4'lü) + 1 L. İçecek", PhotoPath = "~/img/Menus/ProGamerBigKing®Menü.webp", Price = 125 },

                new Product { ProductId = 52, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "Klasik İkili Menü", Description = "Chicken Royale® + Whopper ® + Patates Kızartması (Orta Boy) Patates + 1 L. İçecek", PhotoPath = "~/img/Menus/KlasikİkiliMenü.webp", Price = 185 },

                new Product { ProductId = 53, CategoryId = 6, Name = " 5'li Whopper Menü", Description = "5 Adet Whopper Jr.® + Patates Kızartması (King) + Soğan Halkası (10’lu) + Coca-Cola (1 L.)", PhotoPath = "~/img/Menus/5'liWhopperMenü.webp", Price = 280 },

                new Product { ProductId = 54, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "3’lü Big King Menü", Description = "3 Adet Big King® + Patates Kızartması (Büyük) + 1 L. İçecek", PhotoPath = "~/img/Menus/3’lüBigKing.webp", Price = 280 },

                new Product { ProductId = 55, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "Kral İkili Menü", Description = "Big King® + King Chicken® + Patates Kızartması (Orta) + 1 L İçecek", PhotoPath = "~/img/Menus/KralİkiliMenü.webp", Price = 285 },

                new Product { ProductId = 56, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "2'li Gurme Menü", Description = "2 Adet Seçeceğiniz Sandviç + Patates Kızartması (Orta) + 1 L. İçecek", PhotoPath = "~/img/Menus/2'liGurmeMenü.webp", Price = 260 },

                new Product { ProductId = 57, CategoryId = 6, SalesStatus = SalesStatus.InSale, Name = "4’lü Big King Menü", Description = "4 Adet Big King® + Patates Kızartması (Büyük) + 1 L. İçecek", PhotoPath = "~/img/Menus/4’lüBigKingMenü.webp", Price = 340 }
            );

        }
    }
}
