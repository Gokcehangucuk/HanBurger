﻿using HanBurger.Models;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Context.Seed
{
    public class CategorySeed
    {
        public void AddCategoryData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = 1, Name = "Burgerler", IsActive = true, Description = "En lezzetli hamburgerlerin bir arada bulunduğu kategorimizde, her damak tadına uygun bir seçenek bulabilirsiniz. Tüm hamburgerlerimiz taptaze malzemelerle hazırlanmakta ve özenle sunulmaktadır. Kategorimizde bulunan burgerlarımız arasında klasik lezzetlerden, özel tariflerimize kadar geniş bir yelpaze sunuyoruz.", PhotoPath = "~/img/Burgerler.png" },

            new Category { CategoryId = 2, Name = "Tatlılar", IsActive = true, Description = "Tatlı severlerin vazgeçilmez adresi! En lezzetli tatlıları, en taze malzemelerle hazırlıyoruz. Aradığınız her türlü tatlıyı burada bulabilirsiniz: pasta, cheesecake, dondurma, waffle ve daha fazlası. İster tek başına keyifle yiyin, ister arkadaşlarınızla paylaşın. Afiyet olsun!", PhotoPath = "~/img/Tatlılar.png" },

            new Category { CategoryId = 3, Name = "Soslar", IsActive = true, Description = "Lezzetli yemeklerinizi daha da lezzetlendirecek soslarımızı deneyin! Sıcak ya da soğuk yemeklerinizin yanında kullanabileceğiniz birçok seçeneğimiz var. Özel baharatlarımızla hazırladığımız soslarımız, yemeklerinize farklı tatlar katmanıza yardımcı olacak.", PhotoPath = "~/img/Soslar.png" },

            new Category { CategoryId = 4, Name = "İçecekler", IsActive = true, Description = "İçecekler kategorimizde, ferahlatıcı ve lezzetli seçenekler sunuyoruz. Soğuk yaz günlerinde içinizi serinletecek buzlu içeceklerimiz, kış aylarında ise sizi sıcak tutacak sıcak içeceklerimiz mevcut. Kahve, çay, soda, meyve suları, milkshake ve daha birçok seçenek arasından dilediğinizi seçebilirsiniz. Ayrıca sağlıklı bir seçenek isteyenler için de light içeceklerimiz bulunuyor. İçeceklerimizi, yemeklerinizin yanında veya sadece canınızın istediği bir zaman sipariş edebilirsiniz.", PhotoPath = "~/img/İçecekler.png" },


            new Category { CategoryId = 5, Name = "Özel Menüler", IsActive = true, Description = "Özel Menüler kategorisinde, benzersiz ve özel olarak tasarlanmış menü seçeneklerimizi sunuyoruz. Bu menüler, özel tarifler ve özel lezzetler içerir ve deneyimli şeflerimiz tarafından özenle hazırlanır. Farklı damak zevklerine hitap eden özel menülerimiz arasından seçim yaparak kendinizi şımartabilir ve özel bir yemek deneyimi yaşayabilirsiniz.", PhotoPath = "~/img/ÖzelDoubleWhooperJr.®Menü.webp" },

             new Category { CategoryId = 6, Name = "Menüler", IsActive = true, Description = "Menüler kategorisinde, özel olarak hazırlanmış ve uygun fiyatlı menü seçeneklerimizi sunuyoruz. Bu menüler, ana yemek, yan ürün ve içecek kombinasyonlarından oluşur ve çeşitli tercihlere hitap eder. İhtiyaçlarınıza ve zevkinize uygun menüler arasından seçim yapabilir ve lezzetli bir yemek deneyimi yaşayabilirsiniz.", PhotoPath = "~/img/KralİkiliMenü.webp" }
            );
        }
    }
}
