﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HanBurger.Migrations
{
    public partial class v100 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    PhotoPath = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryID);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    OrderID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderDate = table.Column<DateTime>(type: "date", nullable: true),
                    TotalPrice = table.Column<decimal>(type: "decimal(18,2)", fixedLength: true, maxLength: 10, nullable: true),
                    Status = table.Column<int>(type: "int", maxLength: 50, nullable: true),
                    UserID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.OrderID);
                    table.ForeignKey(
                        name: "FK_Orders_User",
                        column: x => x.UserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ProductID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    PhotoPath = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Description = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    CategoryID = table.Column<int>(type: "int", nullable: true),
                    SalesStatus = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ProductID);
                    table.ForeignKey(
                        name: "FK_Products_Categories",
                        column: x => x.CategoryID,
                        principalTable: "Categories",
                        principalColumn: "CategoryID");
                });

            migrationBuilder.CreateTable(
                name: "OrdersProducts",
                columns: table => new
                {
                    ProductID = table.Column<int>(type: "int", nullable: false),
                    OrderID = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    BreadSize = table.Column<int>(type: "int", nullable: true),
                    SelectedSauces = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrdersProducts", x => new { x.ProductID, x.OrderID });
                    table.ForeignKey(
                        name: "FK_OrdersProducts_Orders",
                        column: x => x.OrderID,
                        principalTable: "Orders",
                        principalColumn: "OrderID");
                    table.ForeignKey(
                        name: "FK_OrdersProducts_Products",
                        column: x => x.ProductID,
                        principalTable: "Products",
                        principalColumn: "ProductID");
                });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "1", "930704e8-3c4e-45b1-b073-f01297e2e0f5", "Admin", "ADMIN" },
                    { "2", "c99b4800-895b-4ed9-acca-317346d6c310", "User", "USER" }
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryID", "Description", "IsActive", "Name", "PhotoPath" },
                values: new object[,]
                {
                    { 1, "En lezzetli hamburgerlerin bir arada bulunduğu kategorimizde, her damak tadına uygun bir seçenek bulabilirsiniz. Tüm hamburgerlerimiz taptaze malzemelerle hazırlanmakta ve özenle sunulmaktadır. Kategorimizde bulunan burgerlarımız arasında klasik lezzetlerden, özel tariflerimize kadar geniş bir yelpaze sunuyoruz.", true, "Burgerler", "~/img/Burgerler.png" },
                    { 2, "Tatlı severlerin vazgeçilmez adresi! En lezzetli tatlıları, en taze malzemelerle hazırlıyoruz. Aradığınız her türlü tatlıyı burada bulabilirsiniz: pasta, cheesecake, dondurma, waffle ve daha fazlası. İster tek başına keyifle yiyin, ister arkadaşlarınızla paylaşın. Afiyet olsun!", true, "Tatlılar", "~/img/Tatlılar.png" },
                    { 3, "Lezzetli yemeklerinizi daha da lezzetlendirecek soslarımızı deneyin! Sıcak ya da soğuk yemeklerinizin yanında kullanabileceğiniz birçok seçeneğimiz var. Özel baharatlarımızla hazırladığımız soslarımız, yemeklerinize farklı tatlar katmanıza yardımcı olacak.", true, "Soslar", "~/img/Soslar.png" },
                    { 4, "İçecekler kategorimizde, ferahlatıcı ve lezzetli seçenekler sunuyoruz. Soğuk yaz günlerinde içinizi serinletecek buzlu içeceklerimiz, kış aylarında ise sizi sıcak tutacak sıcak içeceklerimiz mevcut. Kahve, çay, soda, meyve suları, milkshake ve daha birçok seçenek arasından dilediğinizi seçebilirsiniz. Ayrıca sağlıklı bir seçenek isteyenler için de light içeceklerimiz bulunuyor. İçeceklerimizi, yemeklerinizin yanında veya sadece canınızın istediği bir zaman sipariş edebilirsiniz.", true, "İçecekler", "~/img/İçecekler.png" },
                    { 5, "Özel Menüler kategorisinde, benzersiz ve özel olarak tasarlanmış menü seçeneklerimizi sunuyoruz. Bu menüler, özel tarifler ve özel lezzetler içerir ve deneyimli şeflerimiz tarafından özenle hazırlanır. Farklı damak zevklerine hitap eden özel menülerimiz arasından seçim yaparak kendinizi şımartabilir ve özel bir yemek deneyimi yaşayabilirsiniz.", true, "Özel Menüler", "~/img/ÖzelDoubleWhooperJr.®Menü.webp" },
                    { 6, "Menüler kategorisinde, özel olarak hazırlanmış ve uygun fiyatlı menü seçeneklerimizi sunuyoruz. Bu menüler, ana yemek, yan ürün ve içecek kombinasyonlarından oluşur ve çeşitli tercihlere hitap eder. İhtiyaçlarınıza ve zevkinize uygun menüler arasından seçim yapabilir ve lezzetli bir yemek deneyimi yaşayabilirsiniz.", true, "Menüler", "~/img/KralİkiliMenü.webp" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductID", "CategoryID", "Description", "Name", "PhotoPath", "Price", "SalesStatus" },
                values: new object[,]
                {
                    { 1, 1, "Whopper® eti (dana), 5'' ekmek, turşu, ketçap, mayonez, göbek salata, domates, soğan", "Whopper", "~/img/Burgers/Whopper.webp", 125m, 0 },
                    { 2, 1, "Hamburger eti (dana), 3,75'' ekmek, 1 dilim peynir, turşu, Big King sosu, göbek salata, soğan", "Big King", "~/img/Burgers/BigKing.webp", 110m, 0 },
                    { 3, 1, "Baharatlı Steak Köftesi, 4,5'' ekmek, mayonez, domates, göbek salata, 2 dilim peynir, özel steak sos, çıtır soğan", "BK Steakhouse Burger", "~/img/Burgers/BKSteakhouseBurger.webp", 140m, 0 },
                    { 4, 1, "Texas Smokehouse Burger®, Whopper® eti (dana), 4,5” ekmek, 2 dilim cheddar peyniri, füme kaburga et, barbekü sos, çıtır soğan", "Texas Smokehouse Burger", "~/img/Burgers/TexasSmokehouseBurger.webp", 147m, 0 },
                    { 5, 1, "Whopper® eti (dana), 5'' ekmek, turşu, ketçap, mayonez, göbek salata, domates, soğan", "Whopper Jr.", "~/img/Burgers/WhopperJr.webp", 90m, 0 },
                    { 6, 1, "Whopper® eti (dana), 5'' ekmek, turşu, ketçap, mayonez, göbek salata, domates, soğan", "Double Whopper", "~/img/Burgers/DoubleWhopper.webp", 160m, 0 },
                    { 7, 1, "4,5 \" brioche ekmek, Whopper eti, 2 dilim peynir, marul, mayonez, barbekü sos, çıtır soğan", " Etli Barbekü Brioche", "~/img/Burgers/EtliBarbeküBrioche.webp", 128m, 0 },
                    { 8, 1, "Whopper® eti (dana), 5'' ekmek, 4 dilim peynir, turşu, Big King sosu, göbek salata, soğan", "Big King XXL", "~/img/Burgers/BigKingXXL.webp", 180m, 0 },
                    { 9, 1, "Hamburger eti (dana), 3,75'' ekmek, 2 dilim peynir, turşu, hardal, ketçap", "Double Cheeseburger", "~/img/Burgers/DoubleCheeseburger.webp", 110m, 0 },
                    { 10, 1, "Whopper eti, 5\" ekmek, mayonez, göbek salata, 4 adet soğan halkası, 2 dilim domates, barbekü sos, 2 dilim peynir", "Rodeo Whoppe", "~/img/Burgers/RodeoWhoppe.webp", 140m, 0 },
                    { 11, 1, "Hamburger eti (dana), 3,75'' ekmek, 1 dilim peynir, turşu, hardal, ketçap", "Cheeseburger", "~/img/Burgers/Cheeseburger.webp", 84m, 0 },
                    { 12, 2, "Eşsiz Lezzet Böğürtlenli Çikolatalı Pasta", "Böğürtlenli Çikolatalı Pasta", "~/img/Desserts/BöğürtlenliÇikolatalıPasta.webp", 24m, 0 },
                    { 13, 2, "Eşsiz Lezzet Brownie ", "Brownie", "~/img/Desserts/Brownie.webp", 24m, 0 },
                    { 14, 2, "Eşsiz Lezzet Çikolatalı Muffin", "Çikolatalı Muffin", "~/img/Desserts/ÇikolatalıMuffin.webp", 21m, 0 },
                    { 15, 2, "Eşsiz Lezzet Çokoburger", "Çokoburger", "~/img/Desserts/Çokoburger.webp", 18m, 0 },
                    { 16, 2, "Eşsiz Lezzet Frambuazlı Cheesecake", "Frambuazlı Cheesecake", "~/img/Desserts/FrambuazlıCheesecake.webp", 24m, 0 },
                    { 17, 2, "Eşsiz Lezzet Ekler", "Ekler", "~/img/Desserts/Ekler.webp", 14m, 0 },
                    { 18, 2, "Eşsiz Lezzet Mozaik Pasta", "Mozaik Pasta", "~/img/Desserts/MozaikPasta.webp", 24m, 0 },
                    { 19, 2, "Eşsiz Lezzet Muffin", "Muffin", "~/img/Desserts/Muffin.webp", 17m, 0 },
                    { 20, 3, "Eşsiz Lezzet Ketçap ", "Ketçap", "~/img/Sauces/Ketçap.webp", 2.5m, 0 },
                    { 21, 3, "Eşsiz Lezzet Mayonez  ", "Mayonez ", "~/img/Sauces/Mayonez.webp", 2.5m, 0 },
                    { 22, 3, "Eşsiz Lezzet Acı Sos ", "Acı Sos", "~/img/Sauces/AcıSos.webp", 2.5m, 0 },
                    { 23, 3, "Eşsiz Lezzet Barbekü Sos ", "Barbekü Sos", "~/img/Sauces/BarbeküSos.webp", 3.5m, 0 },
                    { 24, 3, "Eşsiz Lezzet Buffalo Sos ", "Buffalo Sos", "~/img/Sauces/BuffaloSos.webp", 3.5m, 0 },
                    { 25, 3, "Eşsiz Lezzet Ballı Hardal ", "Ballı Hardal", "~/img/Sauces/BallıHardal.webp", 3.5m, 0 },
                    { 26, 4, "Eşsiz Lezzet Coca-Cola (33 cl.)", "Coca-Cola (33 cl.)", "~/img/Drinks/Coca-Cola(33 cl.).webp", 18m, 0 },
                    { 27, 4, "Eşsiz Lezzet Fuse Tea Şeftali (33 cl.)", "Fuse Tea Şeftali (33 cl.)", "~/img/Drinks/FuseTeaŞeftali(33 cl.).webp", 18m, 0 },
                    { 28, 4, "Eşsiz Lezzet Fuse Tea Limon (33 cl.)", "Fuse Tea Limon (33 cl.)", "~/img/Drinks/FuseTeaLimon(33 cl.).webp", 18m, 0 },
                    { 29, 4, "Eşsiz Lezzet Sprite ", "Sprite(33 cl.)", "~/img/Drinks/Sprite(33 cl.).webp", 18m, 0 },
                    { 30, 4, "Eşsiz Lezzet Fanta  (33 cl.)", "Fanta (33 cl.)", "~/img/Drinks/Fanta(33 cl.).webp", 18m, 0 },
                    { 31, 4, "Eşsiz Lezzet Coca-Cola (1 L.)", "Coca-Cola (1 L.)", "~/img/Drinks/Coca-Cola(1 L.).webp", 22m, 0 },
                    { 32, 4, "Eşsiz Lezzet Fuse Tea Şeftali (1 L.)", "Fuse Tea Şeftali (1 L.)", "~/img/Drinks/FuseTeaŞeftali(1 L.).webp", 22m, 0 },
                    { 33, 4, "Eşsiz Lezzet Fuse Tea Limon (1 L.)", "Fuse Tea Limon (1 L.)", "~/img/Drinks/FuseTeaLimon(1 L.).webp", 22m, 0 },
                    { 34, 4, "Eşsiz Lezzet Sprite (1 L.)", "Sprite (1 L.)", "~/img/Drinks/Sprite(1 L.).webp", 22m, 0 },
                    { 35, 4, "Eşsiz Lezzet Fanta  (1 L.)", "Fanta (1 L.)", "~/img/Drinks/Fanta(1 L.).webp", 22m, 0 },
                    { 36, 4, "Eşsiz Lezzet Su", "Su", "~/img/Drinks/Su.webp", 8m, 0 },
                    { 37, 5, "Double Cheeseburger + Patates Kızartması (Orta) + BK King Nuggets (4'lü) + Kutu İçecek", "Özel Double Cheeseburger Menü", "~/img/Menus/ÖzelDoubleCheeseburgerMenü.webp", 120m, 0 },
                    { 38, 5, "Double Whooper Jr.® + Orta Patates + Soğan Halkası (8'li) + Kutu İçecek", "Özel Double Whooper Jr.® Menü", "~/img/Menus/ÖzelDoubleWhooperJr.®Menü.webp", 130m, 0 },
                    { 39, 5, "BK Steakhouse Burger® + Patates Kızartması (Orta) + Soğan Halkası (6'lı) + Kutu İçecek", "Özel BK Steakhouse Burger", "~/img/Menus/ÖzelBKSteakhouseBurger.webp", 150m, 0 },
                    { 40, 5, "Big King® + Patates Kızartması (Orta) + Kutu İçecek", "Özel Big King® Menü", "~/img/Menus/ÖzelBigKing®Menü.®Menü.webp", 105m, 0 },
                    { 41, 5, "2 Adet Chicken Royale + Orta Boy Patates + 4'lü Soğan Halkası + 1 L. İçecek", "Özel Burger King® Menü", "~/img/Menus/ÖzelBurgerKing®Menü.webp", 120m, 0 },
                    { 42, 5, "Etli BBQ Deluxe + Chicken Royale + Patates Kızartması (Orta) + Soğan Halkası (4’lü) + 1 L. İçecek", "Özel Galatasaray Menüsü ", "~/img/Menus/Özel-Galatasaray®Menü.webp", 135m, 0 }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductID", "CategoryID", "Description", "Name", "PhotoPath", "Price", "SalesStatus" },
                values: new object[,]
                {
                    { 43, 5, "Double King Chicken® + Patates Kızartması (Orta) + Kutu İçecek", "Özel Double King Chicken® Menü ", "~/img/Menus/ÖzelDoubleKingChicken®Menü.webp", 90m, 0 },
                    { 44, 5, "2 Adet Seçeceğiniz Sandviç + Patates Kızartması (Orta) + 1 L. İçecek", "Özel Benim İkilim ", "~/img/Menus/ÖzelBenimİkilim®Menü.webp", 100m, 0 },
                    { 45, 5, "3 Adet Whopper Jr.® + Patates Kızartması (Büyük) + Coca-Cola (1 L.)", "Özel 3'lü Whopper®  ", "~/img/Menus/Özel3'lüWhopper®Menü.webp", 180m, 0 },
                    { 46, 6, "Big King® + King Chicken® + Patates Kızartması (Orta) + 1 L İçecek", "Kral İkili Menü", "~/img/Menus/KralİkiliMenü.webp", 165m, 0 },
                    { 47, 6, "BDouble Whopper Jr.® + King Chicken® + Orta Boy Patates + 4’lü Soğan Halkası + 1L. İçecek", "Kral Avantaj Menü", "~/img/Menus/KralAvantajMenü.webp", 145m, 0 },
                    { 48, 6, "Big King® + Big King® + Patates Kızartması (Orta) +1 L. İçecek", "2'li Big King Menü", "~/img/Menus/2'liBigKingMenü.webp", 200m, 0 },
                    { 49, 6, "Big King® + King Chicken® + Patates Kızartması (Orta) + 1 L İçecek", "Benim Üçlüm Menü", "~/img/Menus/BenimÜçlümMenü.webp", 140m, 0 },
                    { 50, 6, "4 Adet Seçeceğiniz Sandviç + Patates Kızartması (Büyük) + 1 L. ", "Benim Dörtlüm Menü", "~/img/Menus/BenimDörtlümMenü.webp", 140m, 0 },
                    { 51, 6, "Big King® + Patates Kızartması (Orta) + Soğan Halkaları (4'lü) + 1 L. İçecek", "Pro Gamer Big King® Menü", "~/img/Menus/ProGamerBigKing®Menü.webp", 125m, 0 },
                    { 52, 6, "Chicken Royale® + Whopper ® + Patates Kızartması (Orta Boy) Patates + 1 L. İçecek", "Klasik İkili Menü", "~/img/Menus/KlasikİkiliMenü.webp", 185m, 0 },
                    { 53, 6, "5 Adet Whopper Jr.® + Patates Kızartması (King) + Soğan Halkası (10’lu) + Coca-Cola (1 L.)", " 5'li Whopper Menü", "~/img/Menus/5'liWhopperMenü.webp", 280m, 0 },
                    { 54, 6, "3 Adet Big King® + Patates Kızartması (Büyük) + 1 L. İçecek", "3’lü Big King Menü", "~/img/Menus/3’lüBigKing.webp", 280m, 0 },
                    { 55, 6, "Big King® + King Chicken® + Patates Kızartması (Orta) + 1 L İçecek", "Kral İkili Menü", "~/img/Menus/KralİkiliMenü.webp", 285m, 0 },
                    { 56, 6, "2 Adet Seçeceğiniz Sandviç + Patates Kızartması (Orta) + 1 L. İçecek", "2'li Gurme Menü", "~/img/Menus/2'liGurmeMenü.webp", 260m, 0 },
                    { 57, 6, "4 Adet Big King® + Patates Kızartması (Büyük) + 1 L. İçecek", "4’lü Big King Menü", "~/img/Menus/4’lüBigKingMenü.webp", 340m, 0 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_UserID",
                table: "Orders",
                column: "UserID");

            migrationBuilder.CreateIndex(
                name: "IX_OrdersProducts_OrderID",
                table: "OrdersProducts",
                column: "OrderID");

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategoryID",
                table: "Products",
                column: "CategoryID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "OrdersProducts");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
