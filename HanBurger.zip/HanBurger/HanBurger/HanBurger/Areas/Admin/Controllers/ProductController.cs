﻿using HanBurger.Context;
using HanBurger.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Areas.Admin.Controllers
{
    [Authorize(Roles = "Admin")]
    [Area("Admin")]
    public class ProductController : Controller
    {
        private readonly HanBurgerDBContext _db;

        public ProductController(HanBurgerDBContext db)
        {
            _db = db;
        }

        public IActionResult AddProduct()
        {
            ViewBag.LevelName = _db.Categories.Select(b => new SelectListItem { Text = b.CategoryId + " " + b.Name, Value = b.CategoryId.ToString() });
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct(Product product, IFormFile? file)
        {

            if (ModelState.IsValid)
            {
                if (file != null && file.Length > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\img\\", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    product.PhotoPath = "/img/" + fileName;
                }
                else
                {
                    product.PhotoPath = "/img/default_product.png";
                }
                await _db.Products.AddAsync(product);
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Kategori başarıyla eklendi.";
                return View();
            }
            else
            {
                return View(product);
            }
        }
        public IActionResult AddCategory()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddCategory(Category category, IFormFile? file)
        {

            if (ModelState.IsValid)
            {
                if (file != null && file.Length > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\img\\", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    category.PhotoPath = "/img/" + fileName;
                }
                else
                {
                    category.PhotoPath = "/img/default_product.png";
                }
                await _db.Categories.AddAsync(category);
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Ürün başarıyla eklendi.";
                return View();
            }
            else
            {
                return View(category);
            }
        }
        public async Task<IActionResult> UpdateProduct(int id)
        {
            ViewBag.LevelName = _db.Categories.Select(b => new SelectListItem { Text = b.CategoryId + " " + b.Name, Value = b.CategoryId.ToString() });
            return View(await _db.Products.FindAsync(id));
        }
        [HttpPost]
        public async Task<IActionResult> UpdateProduct(Product product, IFormFile? file)
        {

            if (ModelState.IsValid)
            {
                if (file != null && file.Length > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\img\\", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    product.PhotoPath = "/img/" + fileName;
                }
                else
                {
                    var existingPhoto = await _db.Products.AsNoTracking().FirstOrDefaultAsync(a => a.ProductId == product.ProductId);
                    product.PhotoPath = existingPhoto.PhotoPath;
                }
                _db.Products.Update(product);
                await _db.SaveChangesAsync();

                TempData["SuccessMessage"] = "Ürün başarıyla Güncellendi.";
                return View();
            }
            else
            {
                TempData["SuccessMessage"] = "Ürün Güncellenmesi sırasında bir hata oluştu.";
                return View(product);
            }
        }
        public async Task<IActionResult> UpdateCategory(int id)
        {
            return View(await _db.Categories.FindAsync(id));
        }

        [HttpPost]
        public async Task<IActionResult> UpdateCategory(Category category, IFormFile? file)
        {


            if (ModelState.IsValid)
            {
                if (file != null && file.Length > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\img\\", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    category.PhotoPath = "/img/" + fileName;
                }
                else
                {
                    var existingPhoto = await _db.Categories.AsNoTracking().FirstOrDefaultAsync(a => a.CategoryId == category.CategoryId);
                    category.PhotoPath = existingPhoto.PhotoPath;
                }
                _db.Categories.Update(category);
                await _db.SaveChangesAsync();
                TempData["SuccessMessage"] = "Kategori başarıyla Güncellendi.";
                return View();
            }
            else
            {
                TempData["SuccessMessage"] = "Kategori Güncellenmesi sırasında bir hata oluştu.";
                return View(category);
            }
        }
    }


}
