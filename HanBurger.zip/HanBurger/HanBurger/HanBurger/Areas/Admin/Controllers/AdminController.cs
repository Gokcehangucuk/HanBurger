﻿using HanBurger.Context;
using HanBurger.Models;
using HanBurger.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Areas.Admin.Controllers
{
	[Authorize(Roles = "Admin")]
	[Area("Admin")]
	public class AdminController : Controller
	{
		private readonly UserManager<AppUser> _userManager;
		private readonly SignInManager<AppUser> _signInManager;
		private readonly RoleManager<IdentityRole> _roleManager;
		private readonly HanBurgerDBContext _db;

		public AdminController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager, RoleManager<IdentityRole> roleManager, HanBurgerDBContext db)
		{
			_signInManager = signInManager;
			_userManager = userManager;
			_roleManager = roleManager;
			_db = db;
		}
		public ActionResult Index()
		{
			int todaySale = _db.OrdersProducts
				.Where(op => op.Order.OrderDate.HasValue && op.Order.OrderDate.Value.Date == DateTime.Today)
				.Sum(op => op.Quantity);
			int totalSale = _db.OrdersProducts.Sum(op => op.Quantity);
			decimal todayRevenue = (decimal)_db.OrdersProducts
				.Where(op => op.Order.OrderDate.HasValue && op.Order.OrderDate.Value.Date == DateTime.Today)
				.Sum(op => op.Quantity * op.Product.Price);
			decimal totalRevenue = (decimal)_db.OrdersProducts.Sum(op => op.Quantity * op.Product.Price);
			List<OrderViewModel> orders = _db.Orders
													.Where(o => o.OrderDate.HasValue && o.OrderDate.Value.Date == DateTime.Today)
													.Select(o => new OrderViewModel
													{
														OrderNumber = o.OrderId,
														CustomerName = o.User.UserName,
														OrderDate = o.OrderDate.Value,
														OrderTotal = (decimal)o.TotalPrice,
														Products = o.OrdersProducts.Select(op => new ProductViewModel
														{
															ProductName = op.Product.Name,
															Quantity = op.Quantity,
															TotalPrice = (decimal)(op.Quantity * op.Product.Price)
														}).ToList()
													}).ToList();
			var viewModel = new StatisticsAndOrdersViewModel
			{
				TodaySale = todaySale,
				TotalSale = totalSale,
				TodayRevenue = todayRevenue,
				TotalRevenue = totalRevenue,
				Orders = orders
			};
			return View(viewModel);
		}
		[HttpPost]
		public IActionResult Index(DateTime startDate, DateTime endDate)
		{
			int todaySale = _db.OrdersProducts
			   .Where(op => op.Order.OrderDate.HasValue && op.Order.OrderDate.Value.Date == DateTime.Today)
			   .Sum(op => op.Quantity);
			int totalSale = _db.OrdersProducts.Sum(op => op.Quantity);
			decimal todayRevenue = (decimal)_db.OrdersProducts
				.Where(op => op.Order.OrderDate.HasValue && op.Order.OrderDate.Value.Date == DateTime.Today)
				.Sum(op => op.Quantity * op.Product.Price);
			decimal totalRevenue = (decimal)_db.OrdersProducts.Sum(op => op.Quantity * op.Product.Price);
			var filteredOrders = _db.Orders
				.Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
				.Select(o => new OrderViewModel
				{
					OrderNumber = o.OrderId,
					CustomerName = o.User.UserName,
					OrderDate = o.OrderDate.Value,
					OrderTotal = (decimal)o.TotalPrice,
					Products = o.OrdersProducts.Select(op => new ProductViewModel
					{
						ProductName = op.Product.Name,
						Quantity = op.Quantity,
						TotalPrice = (decimal)(op.Quantity * op.Product.Price)
					}).ToList()
				}).ToList();
			var viewModel = new StatisticsAndOrdersViewModel
			{
				TodaySale = todaySale,
				TotalSale = totalSale,
				TodayRevenue = todayRevenue,
				TotalRevenue = totalRevenue,
				Orders = filteredOrders
			};

			return View(viewModel);
		}
		public IActionResult ViewMessage()
		{
			var users = _userManager.Users.ToList();
			return View(users);
		}
		public async Task<IActionResult> AllProductsCategory()
		{
			var categories = await _db.Categories.Include(c => c.Products).ToListAsync();
			return View(categories);
		}



	}
}
