﻿using Microsoft.AspNetCore.Identity;

namespace HanBurger.Models
{
    public partial class AppUser : IdentityUser
    {
        public AppUser()
        {
            Orders = new HashSet<Order>();
        }
        public virtual ICollection<Order> Orders { get; set; }

        public string Address { get; set; }
        public string Country { get; set; }

        public string City { get; set; }
        public string? Message { get; set; }
    }
}
