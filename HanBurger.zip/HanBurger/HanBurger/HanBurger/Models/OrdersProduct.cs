﻿using HanBurger.Models.Enums;

namespace HanBurger.Models
{
    public partial class OrdersProduct
    {
        public int ProductId { get; set; }

        public int OrderId { get; set; }
        public int Quantity { get; set; } = 1;
        public BreadSize? BreadSize { get; set; }

        public List<string>? SelectedSauces { get; set; } = new List<string>();

        public virtual Order Order { get; set; } = null!;
        public virtual Product Product { get; set; } = null!;
    }
}
