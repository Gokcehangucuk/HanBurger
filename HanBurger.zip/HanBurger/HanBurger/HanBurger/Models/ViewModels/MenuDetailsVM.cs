﻿using System.ComponentModel.DataAnnotations.Schema;
using HanBurger.Models.Enums;

namespace HanBurger.Models.ViewModels
{
	[NotMapped]
	public class MenuDetailsVM
	{
		public MenuDetailsVM()
		{
			products = new List<Product>();

		}
		public Product Product { get; set; }

		public List<Product> products { get; set; }
		public decimal TotalPrice { get; set; }

		public int Quantity { get; set; } = 1;
		public BreadSize? BreadSize { get; set; }
	}
}
