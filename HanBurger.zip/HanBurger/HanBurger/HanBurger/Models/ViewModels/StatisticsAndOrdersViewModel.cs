﻿namespace HanBurger.Models.ViewModels
{

    public class StatisticsAndOrdersViewModel
    {
        public int TodaySale { get; set; }
        public int TotalSale { get; set; }
        public decimal TodayRevenue { get; set; }
        public decimal TotalRevenue { get; set; }
        public List<OrderViewModel> Orders { get; set; }
    }

}
