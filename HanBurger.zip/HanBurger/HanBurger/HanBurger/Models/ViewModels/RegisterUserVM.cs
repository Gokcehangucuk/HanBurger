﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HanBurger.Models.ViewModels
{
    [NotMapped]
    public class RegisterUserVM
    {
        [Required(ErrorMessage = "Kullanıcı Adı Bilgisi Boş bırakılamaz...")]
        [StringLength(15, ErrorMessage = "Lütfen kullanıcı adını 4 ile 15 karakter arasında giriniz...", MinimumLength = 4)]
        [Display(Name = "Kullanıcı Adı")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Email Bilgisi Boş bırakılamaz...")]
        [EmailAddress(ErrorMessage = "Lütfen email formatında bir değer belirtiniz...")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Şifre Bilgisi Boş bırakılamaz...")]
        //[DataType(DataType.Password, ErrorMessage = "Lütfen şifreyi tüm kuralları göz önüne alarak giriniz...")]
        [Display(Name = "Şifre")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Şifre Tekrarı Bilgisi Boş bırakılamaz...")]
        //[DataType(DataType.Password, ErrorMessage = "Lütfen şifreyi tüm kuralları göz önüne alarak giriniz...")]
        [Display(Name = "Şifre Tekrarı")]
        [Compare("Password", ErrorMessage = "Şifreler uyuşmuyor.")]
        public string RePassword { get; set; }

        [Required(ErrorMessage = "Telefon Numarası Bilgisi Boş bırakılamaz...")]
        [RegularExpression(@"^\d{11}$", ErrorMessage = "Lütfen geçerli bir telefon numarası giriniz (10 haneli)...")]
        [Display(Name = "Telefon")]
        public string PhoneNumber { get; set; }


        [Required(ErrorMessage = "Adres Bilgisi Boş bırakılamaz...")]
        [Display(Name = "Adres")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Ülke Bilgisi Boş bırakılamaz...")]
        [Display(Name = "Ülke")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Şehir Bilgisi Boş bırakılamaz...")]
        [Display(Name = "Şehir")]
        public string City { get; set; }

    }
}
