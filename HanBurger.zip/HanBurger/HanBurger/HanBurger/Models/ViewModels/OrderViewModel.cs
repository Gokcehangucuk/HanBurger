﻿namespace HanBurger.Models.ViewModels
{
    public class OrderViewModel
    {
        public int OrderNumber { get; set; }
        public string CustomerName { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal OrderTotal { get; set; }
        public List<ProductViewModel> Products { get; set; }
    }
}
