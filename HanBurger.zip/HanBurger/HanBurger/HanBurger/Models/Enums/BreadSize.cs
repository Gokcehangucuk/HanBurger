﻿namespace HanBurger.Models.Enums
{
	public enum BreadSize
	{
		Küçük,
		Orta,
		Büyük
	}
}
