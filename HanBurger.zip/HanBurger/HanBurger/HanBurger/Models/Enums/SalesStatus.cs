﻿namespace HanBurger.Models.Enums
{
    public enum SalesStatus
    {
        InSale,
        NotInSale
    }
}
