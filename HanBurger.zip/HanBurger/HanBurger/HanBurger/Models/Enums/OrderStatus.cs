﻿namespace HanBurger.Models.Enums
{
	public enum OrderStatus
	{
		InProgress,
		Completed
	}
}
