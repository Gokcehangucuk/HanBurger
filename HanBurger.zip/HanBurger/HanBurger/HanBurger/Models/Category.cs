﻿using System.ComponentModel.DataAnnotations;

namespace HanBurger.Models
{
    public partial class Category
    {
        public Category()
        {
            Products = new HashSet<Product>();
        }
        [Key]
        public int CategoryId { get; set; }
        public string? Name { get; set; }
        public string? PhotoPath { get; set; }
        public string? Description { get; set; }

        public bool IsActive { get; set; } = true;

        public virtual ICollection<Product> Products { get; set; }
    }
}
