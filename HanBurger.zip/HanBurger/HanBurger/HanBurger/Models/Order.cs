﻿using System.ComponentModel.DataAnnotations;
using HanBurger.Models.Enums;

namespace HanBurger.Models
{
    public partial class Order
    {
        public Order()
        {
            OrdersProducts = new HashSet<OrdersProduct>();
        }
        [Key]
        public int OrderId { get; set; }
        public DateTime? OrderDate { get; set; }
        public decimal? TotalPrice { get; set; }
        public OrderStatus? Status { get; set; } = OrderStatus.InProgress;
        public string UserId { get; set; } = null!;

        public int Quantity { get; set; } = 1;

        public virtual AppUser User { get; set; } = null!;
        public virtual ICollection<OrdersProduct> OrdersProducts { get; set; }
    }
}
