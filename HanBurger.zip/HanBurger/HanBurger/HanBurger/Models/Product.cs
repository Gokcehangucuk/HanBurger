﻿using System.ComponentModel.DataAnnotations;
using HanBurger.Models.Enums;

namespace HanBurger.Models
{
    public partial class Product
    {
        public Product()
        {
            OrdersProducts = new HashSet<OrdersProduct>();
        }
        [Key]
        public int ProductId { get; set; }
        public string? Name { get; set; }
        public string? PhotoPath { get; set; }
        public string? Description { get; set; }
        public decimal? Price { get; set; }
        public int? CategoryId { get; set; }
        public SalesStatus SalesStatus { get; set; }

        public virtual Category? Category { get; set; }
        public virtual ICollection<OrdersProduct> OrdersProducts { get; set; }
    }
}
