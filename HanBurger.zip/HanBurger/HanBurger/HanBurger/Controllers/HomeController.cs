﻿using System.Diagnostics;
using HanBurger.Context;
using HanBurger.Models;
using HanBurger.Models.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace HanBurger.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly HanBurgerDBContext _db;
        private readonly UserManager<AppUser> _userManager;
        public HomeController(ILogger<HomeController> logger, HanBurgerDBContext db, UserManager<AppUser> userManager)
        {
            _logger = logger;
            _db = db;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult HomePage()
        {
            var menuList = _db.Products.Where(bur => bur.Name.Contains("Özel") && bur.SalesStatus == SalesStatus.InSale).ToList();
            return View(menuList);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [Route("/NotFound")]
        public IActionResult NotFoundError404()
        {
            return View();
        }
        [Authorize]
        public IActionResult ContactUs()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ContactUs(string message)
        {
            if (!string.IsNullOrEmpty(message))
            {
                // Kullanıcıyı almak için giriş yapmış olma kontrolü yapılabilir
                AppUser user = await _userManager.GetUserAsync(HttpContext.User);
                if (user != null)
                {
                    user.Message = message;
                    await _userManager.UpdateAsync(user);
                    _db.SaveChanges();

                    // ViewBag üzerinden mesajın gösterileceği değişkeni ayarla
                    ViewBag.ShowThankYouMessage = true;
                }
            }

            // İşlem tamamlandıktan sonra view'i döndür
            return View();
        }

    }
}