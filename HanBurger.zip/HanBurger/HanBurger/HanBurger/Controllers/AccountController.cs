﻿using HanBurger.Context;
using HanBurger.Models;
using HanBurger.Models.Enums;
using HanBurger.Models.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly HanBurgerDBContext _db;

        public AccountController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager, RoleManager<IdentityRole> roleManager, HanBurgerDBContext db)
        {
            _signInManager = signInManager;
            _userManager = userManager;
            _roleManager = roleManager;
            _db = db;
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterUserVM registerUserVM, string role = "USER")
        {
            IActionResult viewResult = null;
            ModelState.Remove("role");
            if (ModelState.IsValid)
            {

                var userByName = await _userManager.FindByNameAsync(registerUserVM.UserName);
                var userByEmail = await _userManager.FindByEmailAsync(registerUserVM.Email);
                if (userByName != null || userByEmail != null)
                {
                    ModelState.AddModelError("Email", "Bu username ya da email adresine sahip kullanıcı sistemde bulunmaktadır!");
                    viewResult = View(registerUserVM);
                }
                else
                {
                    if (registerUserVM.Password != registerUserVM.RePassword)
                    {
                        ModelState.AddModelError("RePassword", "Şifreler Aynı değildir!");
                        viewResult = View(registerUserVM);
                    }
                    else
                    {
                        var userRole = await _roleManager.FindByNameAsync(role);

                        AppUser eklenecekKullanici = new()
                        {
                            UserName = registerUserVM.UserName,
                            Email = registerUserVM.Email,
                            Address = registerUserVM.Address,
                            Country = registerUserVM.Country,
                            City = registerUserVM.City
                        };
                        var eklemeSonucu = await _userManager.CreateAsync(eklenecekKullanici, registerUserVM.Password);
                        if (eklemeSonucu.Succeeded)
                        {
                            await _userManager.AddToRoleAsync(eklenecekKullanici, role);
                            viewResult = RedirectToAction("HomePage", "Home");
                        }
                        else
                        {
                            ModelState.AddModelError("UserName", "Kullanıcı sisteme kayıt edilirken sunucuda hata oluştu!");
                            viewResult = View(registerUserVM);
                        }
                    }
                    viewResult = View(registerUserVM);

                }
            }
            else
            {
                viewResult = View(registerUserVM);
            }

            return viewResult;
        }
        public IActionResult SignIn()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SignIn(LoginVM loginVM)
        {
            IActionResult viewResult = null;
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByEmailAsync(loginVM.Email);
                var user2 = await _signInManager.CheckPasswordSignInAsync(user, loginVM.Password, false);
                if (user != null)
                {
                    if (user2 != null)
                    {
                        if (user2.Succeeded)
                        {
                            HttpContext.Session.SetString("Username", user.UserName);
                            HttpContext.Session.SetString("UserId", user.Id);

                            await _signInManager.SignInAsync(user, false);
                            viewResult = RedirectToAction("HomePage", "Home");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Password", "Hatalı şifre!");
                        viewResult = View(loginVM);
                    }

                }
                else
                {
                    ModelState.AddModelError("UserName", "Bu email adresine kayıtlı kullanıcı bulunamadı!");
                    viewResult = View(loginVM);
                }
            }
            else
            {
                viewResult = View(loginVM);
            }


            return viewResult;
        }

        public async Task<IActionResult> SignOut()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("SignIn", "Account");
        }
        public async Task<IActionResult> Profile()
        {
            string userId = HttpContext.Session.GetString("UserId");
            AppUser user = _userManager.Users.FirstOrDefault(x => x.Id.Equals(userId));
            if (user == null)
            {
                return RedirectToAction("SignIn", "Account");
            }
            RegisterUserVM registerUserVM = new RegisterUserVM()
            {
                Address = user.Address,
                City = user.City,
                Country = user.Country,
                Email = user.Email,
                Password = user.PasswordHash,
                PhoneNumber = user.PhoneNumber,
                UserName = user.UserName,
                RePassword = user.PasswordHash
            };
            return View(registerUserVM);
        }
        [HttpPost]
        public async Task<IActionResult> Profile(string id, RegisterUserVM registerUserVM)
        {
            string userId = HttpContext.Session.GetString("UserId");
            AppUser user = _userManager.Users.FirstOrDefault(x => x.Id.Equals(userId));
            if (user == null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                user.Address = registerUserVM.Address;
                user.City = registerUserVM.City;
                user.Country = registerUserVM.Country;
                user.Email = registerUserVM.Email;
                user.PhoneNumber = registerUserVM.PhoneNumber;
                user.UserName = registerUserVM.UserName;
                user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, registerUserVM.Password);
                await _userManager.UpdateAsync(user);
                return View();

            };

            return View(registerUserVM);
        }
        public IActionResult OrderHistory()
        {
            string userId = HttpContext.Session.GetString("UserId");
            AppUser user = _userManager.Users.FirstOrDefault(x => x.Id.Equals(userId));
            var orders = _db.Orders
                            .Include(x => x.User)
                            .Include(x => x.OrdersProducts)
                                .ThenInclude(x => x.Product)
                            .Where(x => x.User == user && x.Status == OrderStatus.Completed).ToList();

            return View(orders);
        }
    }
}
