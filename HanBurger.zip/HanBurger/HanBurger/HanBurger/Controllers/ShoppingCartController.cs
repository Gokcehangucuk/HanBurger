﻿using HanBurger.Context;
using HanBurger.Models;
using HanBurger.Models.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Controllers
{
    [Authorize]
    public class ShoppingCartController : Controller
    {
        private readonly HanBurgerDBContext _db;
        private readonly UserManager<AppUser> _userManager;

        public ShoppingCartController(HanBurgerDBContext db, UserManager<AppUser> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> CartView()
        {
            AppUser user = await _userManager.GetUserAsync(HttpContext.User);
            var products = _db.OrdersProducts
                            .Include(op => op.Order)
                                .ThenInclude(o => o.User)
                            .Include(op => op.Product)
                            .Where(op => op.Order.User == user && op.Order.Status == OrderStatus.InProgress)
                            .ToList();
            return View(products);
        }

        public IActionResult DeleteOrder(int productId, int orderId)
        {
            var removeOrderProduct = _db.OrdersProducts.FirstOrDefault(x => x.OrderId == orderId && x.ProductId == productId);
            _db.OrdersProducts.Remove(removeOrderProduct);
            _db.SaveChanges();
            return RedirectToAction("CartView");
        }
        public async Task<IActionResult> CompleteOrder(int orderId, int quantity, decimal totalAmount)
        {
            string userId = HttpContext.Session.GetString("UserId");
            AppUser user = await _userManager.FindByIdAsync(userId);
            var products = _db.OrdersProducts
                           .Include(op => op.Order)
                             .ThenInclude(o => o.User)
                           .Include(op => op.Product)
                             .Where(op => op.OrderId == orderId && op.Order.Status == OrderStatus.InProgress && op.Order.User == user)
                           .ToList();

            var completeOrder = _db.Orders.FirstOrDefault(x => x.OrderId == orderId);
            completeOrder.Status = OrderStatus.Completed;
            completeOrder.OrderDate = DateTime.Now;
            completeOrder.Quantity = quantity;
            completeOrder.TotalPrice = totalAmount;
            _db.Orders.Update(completeOrder);
            _db.SaveChanges();
            return View(products);
        }

        public ActionResult FinishOrder()
        {
            return View();
        }


    }
}
