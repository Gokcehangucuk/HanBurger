﻿using HanBurger.Context;
using HanBurger.Models;
using HanBurger.Models.Enums;
using HanBurger.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HanBurger.Controllers
{
    public class ProductController : Controller
    {
        private readonly HanBurgerDBContext _db;

        public ProductController(HanBurgerDBContext db)
        {
            _db = db;
        }

        public async Task<IActionResult> MenuDetails(int id)
        {
            MenuDetailsVM menuDetailsVM = new MenuDetailsVM()
            {
                Product = await _db.Products.FindAsync(id),
                products = _db.Products.Include(x => x.Category).Where(x => x.Category.Name.Equals("Soslar") && x.SalesStatus == SalesStatus.InSale && x.Category.IsActive == true).ToList()
            };
            return View(menuDetailsVM);
        }

        public async Task<IActionResult> Products()
        {
            var products = _db.Products.Include(x => x.Category).Where(x => x.SalesStatus == SalesStatus.InSale).ToList();
            return View(products);
        }

        public async Task<IActionResult> ProductDetails(int id)
        {
            Product products = await _db.Products.FindAsync(id);
            return View(products);
        }
        [HttpPost]
        [Authorize]
        public IActionResult AddToOrdersMenu(int productId, int quantity = 1, string ekmekBoyutu = "Küçük", string selectedSoslar1 = null, string selectedSoslar2 = null)
        {
            string userId = HttpContext.Session.GetString("UserId");
            string username = HttpContext.Session.GetString("Username");
            Enum.TryParse(ekmekBoyutu, out BreadSize breadSize);
            var selectedSoslar = new List<string> { selectedSoslar1, selectedSoslar2 };
            var user = _db.Users.Where(user => user.Id == userId).FirstOrDefault();
            var selectedOrder = _db.Orders.Include(x => x.User).FirstOrDefault(x => x.User == user && x.Status.Value == OrderStatus.InProgress);
            var selectedProduct = _db.Products.Where(x => x.ProductId == productId).FirstOrDefault();

            if (selectedOrder != null)
            {
                var existingOrderProduct = _db.OrdersProducts.FirstOrDefault(x => x.ProductId == selectedProduct.ProductId && x.OrderId == selectedOrder.OrderId);
                if (existingOrderProduct != null)
                {
                    existingOrderProduct.Quantity = quantity;
                    existingOrderProduct.SelectedSauces = selectedSoslar;
                    existingOrderProduct.BreadSize = breadSize;
                    _db.SaveChanges();
                }
                else
                {
                    var ordersProduct = new OrdersProduct
                    {
                        Product = selectedProduct,
                        Order = selectedOrder,
                        Quantity = quantity,
                        SelectedSauces = selectedSoslar
                    };
                    _db.OrdersProducts.Add(ordersProduct);
                    _db.SaveChanges();
                }
            }
            else
            {
                Order order = new Order
                {
                    Status = OrderStatus.InProgress,
                    Quantity = quantity,
                    User = user
                };
                var ordersProduct = new OrdersProduct
                {
                    BreadSize = breadSize,
                    Product = selectedProduct,
                    Order = order,
                    Quantity = quantity,
                    SelectedSauces = selectedSoslar
                };
                _db.Orders.Add(order);
                _db.OrdersProducts.Add(ordersProduct);
                _db.SaveChanges();
            }
            @ViewBag.SuccessMessage = "Sipariş başarıyla oluşturuldu.";
            return RedirectToAction("Products", "Product");
        }
        [HttpPost]
        [Authorize]
        public IActionResult AddToOrdersProduct(int productId, int quantity)
        {
            string userId = HttpContext.Session.GetString("UserId");
            string username = HttpContext.Session.GetString("Username");
            var user = _db.Users.Where(user => user.Id == userId).FirstOrDefault();
            var selectedOrder = _db.Orders.Include(x => x.User).FirstOrDefault(x => x.User == user && x.Status.Value == OrderStatus.InProgress);
            var selectedProduct = _db.Products.Where(x => x.ProductId == productId).FirstOrDefault();
            if (selectedOrder != null)
            {
                var existingOrderProduct = _db.OrdersProducts.FirstOrDefault(x => x.ProductId == selectedProduct.ProductId && x.OrderId == selectedOrder.OrderId);
                if (existingOrderProduct != null)
                {
                    existingOrderProduct.Quantity = quantity;
                    _db.OrdersProducts.Update(existingOrderProduct);
                    _db.SaveChanges();
                }
                else
                {
                    var ordersProduct = new OrdersProduct
                    {
                        Product = selectedProduct,
                        ProductId = selectedProduct.ProductId,
                        Order = selectedOrder,
                        OrderId = selectedOrder.OrderId,
                        Quantity = quantity
                    };
                    _db.OrdersProducts.Add(ordersProduct);
                    _db.SaveChanges();
                }
            }
            else
            {
                Order order = new Order
                {
                    Status = OrderStatus.InProgress,
                    Quantity = quantity,
                    UserId = userId
                };
                var ordersProduct = new OrdersProduct
                {
                    Product = selectedProduct,
                    Order = order,
                    BreadSize = null,
                    Quantity = quantity
                };
                _db.Orders.Add(order);
                _db.OrdersProducts.Add(ordersProduct);
                _db.SaveChanges();
            }
            return RedirectToAction("Products", "Product");
        }
    }
}
