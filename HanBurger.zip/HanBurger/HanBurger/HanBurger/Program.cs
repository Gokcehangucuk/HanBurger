using HanBurger.Context;
using HanBurger.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<HanBurgerDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConnectionString")));

builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddControllersWithViews();

builder.Services.AddIdentity<AppUser, IdentityRole>()
    .AddEntityFrameworkStores<HanBurgerDBContext>()
    .AddDefaultTokenProviders();

builder.Services.AddScoped<UserManager<AppUser>>();
builder.Services.AddScoped<SignInManager<AppUser>>();


builder.Services.AddRazorPages();


//builder.Services.ConfigureApplicationCookie(options =>
//{
//    options.Cookie.Name = "UserCookie";
//    options.SlidingExpiration = true;
//    options.ExpireTimeSpan = TimeSpan.FromHours(8);
//    options.LoginPath = "/Account/SignOut";

//});
builder.Services.AddSession(options =>
{
    options.Cookie.Name = "MyApp.Session";
    options.IdleTimeout = TimeSpan.FromHours(8);
    options.Cookie.HttpOnly = true;
    options.Cookie.SameSite = SameSiteMode.Strict;
});
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseSession();

app.UseAuthentication();
app.UseAuthorization();
app.UseStatusCodePagesWithRedirects("/NotFound");

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
       name: "admin",
       pattern: "{area:exists}/{controller=Admin}/{action=Index}/{id?}"
   );

    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=HomePage}/{id?}"
    );

    endpoints.MapRazorPages();
});
app.MapRazorPages();

app.Run();
